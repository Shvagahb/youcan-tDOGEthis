A Pen created at CodePen.io. You can find this one at http://codepen.io/Lane/pen/EBHFk.

 Displays a stack of cards.  When the user hovers (or taps) the cards, they spread out and the user can hover (or tap) each card to see it. 