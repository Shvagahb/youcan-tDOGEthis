A Pen created at CodePen.io. You can find this one at http://codepen.io/eneox/pen/gKrca.

 Eneox Style Text Effect