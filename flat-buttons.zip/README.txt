A Pen created at CodePen.io. You can find this one at http://codepen.io/tholex/pen/nJsLo.

 Simple flat button family similar to bootstrap buttons. Nothing much going on here, just margin + border adding up to the same value on and off hover.
